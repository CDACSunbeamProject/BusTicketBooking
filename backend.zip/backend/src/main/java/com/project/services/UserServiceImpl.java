package com.project.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.custom_exceptions.ApiException;
import com.project.daos.UserDao;
import com.project.dto.UserRequestDTO;
import com.project.dto.UserRespDTO;
import com.project.entities.User;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class UserServiceImpl implements UserService{

	// depcy
		private final UserDao userDao;
		private ModelMapper mapper;
		private PasswordEncoder passwordEncoder;
		
	
	@Override
	public UserRespDTO signUp(UserRequestDTO dto) {
		// 1. check for dup email
		if (userDao.existsByEmail(dto.getEmail()))
					throw new ApiException("Dup Email detected - User exists already!!!!");
				// 2. dto -> entity

		User entity = mapper.map(dto, User.class);
		//3. encrypt password
		entity.setPassword(passwordEncoder.encode(entity.getPassword()));
		//4. save the entity n map persistent entity -> resp dto
		return mapper.map(userDao.save(entity), UserRespDTO.class);
	}
	
}
