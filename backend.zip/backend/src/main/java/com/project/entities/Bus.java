package com.project.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.*;

@Entity
@Table(name = "bus")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Bus extends BaseEntity {
	
    @Column(name = "bus_name", length = 50)
    private String busName;

    @Column(name = "bus_no", unique = true, length = 20)
    private String busNo;

    @Column(name = "bus_type", length = 30)
    private String busType;

    @Column(name = "operator_name", length = 50)
    private String operatorName;

    @Column(name = "no_of_seats")
    private int noOfSeats;

    @Column(name = "departure_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate departure_date;
    
    @Column(name = "departure_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime departure_time;

    @Column(name = "arrival_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate arrival_date;
    
    @Column(name = "arrival_time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime arrival_time;

    @Column(name = "duration")
    private double duration;  // in hours or minutes

    @Column(name = "price")
    private double price;

    @Column(name = "rating")
    private Float rating;

    @Column(name = "amenities", columnDefinition = "TEXT")
    private String amenities; // store JSON array like ["WiFi", "Blanket"]

    //relationships
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "route_id")
    private Route busRoute;
    
    @Transient
    public List<String> getAmenitiesList() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(amenities, new TypeReference<List<String>>() {});
    }

    @Transient
    public void setAmenitiesList(List<String> amenitiesList) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        this.amenities = objectMapper.writeValueAsString(amenitiesList);
    }

}


