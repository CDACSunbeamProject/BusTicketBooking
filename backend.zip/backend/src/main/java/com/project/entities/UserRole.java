package com.project.entities;

public enum UserRole {
	ROLE_ADMIN, ROLE_USER
}
